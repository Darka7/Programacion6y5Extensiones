﻿namespace App{

    export interface DBEntity {
        CodeError?: number;
        MsgError: string;
    }


}