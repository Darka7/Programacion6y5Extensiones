﻿interface JQuery {
    data<T>(element: string): T;
}
