﻿const  enum bvFormValid {
    data = "bootstrapValidator"
}