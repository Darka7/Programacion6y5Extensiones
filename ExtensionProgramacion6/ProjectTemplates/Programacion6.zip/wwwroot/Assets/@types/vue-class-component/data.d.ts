

 declare function collectDataFromConstructor(vm: Vue, Component: VueClass<Vue>): {};
